# Image-Lesson
Demonstration of Images using aspect ratio
